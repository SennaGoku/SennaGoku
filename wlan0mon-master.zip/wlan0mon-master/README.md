## Usage / Использование
```
git clone https://github.com/ripunk/wlan0mon.git

cd wlan0mon          
ls         
chmod +x monen mondis      

#start / запуск     
./monen      

#stop / отключение      
./mondis         
```
[оригинальный скрипт](https://github.com/ripunk/wlan0mon.git) от автора Ripunk
